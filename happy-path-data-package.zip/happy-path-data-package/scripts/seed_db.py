#!/usr/bin/env python3
"""
Happy Path v5.0 Deterministic Database Compiler:
- Honors HAPPY_PATH_DB_PATH environment variable and supports `--if-missing` (prevents accidental session wipe on startup).
- Builds atomic SQLite database via /tmp staging + os.replace().
- Compiles branch-aware multi-vertex edge polylines so alternative branches trace their real branch_waypoints rather than excluded main-spine waypoints.
- Populates corridors, corridor_branches, toll_plazas, pois (with EV kW/port metadata & Google Maps ratings), corridor_edges, poi_co_occurrence, ingestion_audit_log, and poi_reviews.
"""
import argparse
import json
import math
import os
import shutil
import sqlite3
import tempfile
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parent.parent
DEFAULT_DB_PATH = Path(os.environ.get("HAPPY_PATH_DB_PATH", str(ROOT_DIR / "data" / "happy_path.db")))
SCHEMA_PATH = ROOT_DIR / "data" / "schema.sql"
SEED_JSON_PATH = ROOT_DIR / "data" / "seed_corridors.json"
RAW_CANDIDATES_PATH = ROOT_DIR / "data" / "raw_scraped_candidates.json"

TIME_BUCKETS = {
    "early_morning": (62.0, 0.90),
    "day_normal": (52.0, 1.00),
    "peak_congestion": (38.0, 1.35),
    "rain_evening": (42.0, 1.25),
}


def _encode_value(val: int) -> str:
    val = ~(val << 1) if val < 0 else (val << 1)
    chunks = []
    while val >= 0x20:
        chunks.append(chr((0x20 | (val & 0x1F)) + 63))
        val >>= 5
    chunks.append(chr(val + 63))
    return "".join(chunks)


def _encode_coords_polyline(coords: list[tuple[float, float]]) -> str:
    result = []
    prev_lat = 0
    prev_lng = 0
    for lat, lng in coords:
        ilat = int(round(lat * 1e5))
        ilng = int(round(lng * 1e5))
        result.append(_encode_value(ilat - prev_lat))
        result.append(_encode_value(ilng - prev_lng))
        prev_lat, prev_lng = ilat, ilng
    return "".join(result)


def _is_pair_physically_connected(u_br: str, u_km: float, v_br: str, v_km: float, branches_map: dict) -> bool:
    if u_br == "MAIN_SPINE" and v_br == "MAIN_SPINE":
        return True
    if u_br == v_br:
        return True
    lo_km, hi_km = (u_km, v_km) if u_km <= v_km else (v_km, u_km)
    if u_br == "MAIN_SPINE" and v_br != "MAIN_SPINE":
        br = branches_map.get(v_br)
        if not br:
            return False
        if u_km <= v_km:
            return u_km <= br["diverge_km"] + 1e-6
        else:
            return u_km >= br["merge_km"] - 1e-6
    if u_br != "MAIN_SPINE" and v_br == "MAIN_SPINE":
        br = branches_map.get(u_br)
        if not br:
            return False
        if u_km <= v_km:
            return v_km >= br["merge_km"] - 1e-6
        else:
            return v_km <= br["diverge_km"] + 1e-6
    br_u = branches_map.get(u_br)
    br_v = branches_map.get(v_br)
    if not br_u or not br_v:
        return False
    if u_km <= v_km:
        return br_u["merge_km"] <= br_v["diverge_km"] + 1e-6
    else:
        return br_v["merge_km"] <= br_u["diverge_km"] + 1e-6


def _build_branch_aware_edge_coords(
    u_lat: float, u_lng: float, u_km: float, u_br: str,
    v_lat: float, v_lng: float, v_km: float, v_br: str,
    spine_waypoints: list[dict], branches_map: dict
) -> list[tuple[float, float]]:
    """Trace intermediate road waypoints along the active branch or main spine without leaking excluded main-spine points."""
    forward = v_km >= u_km
    lo_km, hi_km = (u_km, v_km) if forward else (v_km, u_lat)
    lo_km, hi_km = min(u_km, v_km), max(u_km, v_km)

    active_branches = []
    for bid in {u_br, v_br}:
        if bid != "MAIN_SPINE" and bid in branches_map:
            active_branches.append(branches_map[bid])

    mid_pts = []
    # Collect main-spine waypoints outside any active branch's (diverge_km, merge_km) exclusion interval
    for wp in spine_waypoints:
        if isinstance(wp, dict):
            wkm, wlat, wlng = float(wp["km"]), float(wp["lat"]), float(wp["lng"])
        else:
            wkm, wlat, wlng = float(wp[0]), float(wp[1]), float(wp[2])
        if lo_km + 0.5 < wkm < hi_km - 0.5:
            in_excluded = any(
                (br["diverge_km"] + 0.1 < wkm < br["merge_km"] - 0.1)
                for br in active_branches
            )
            if not in_excluded:
                mid_pts.append((wkm, wlat, wlng))

    # Collect branch waypoints inside the active branch interval
    for br in active_branches:
        for bwp in br.get("branch_waypoints", []):
            bkm = float(bwp["km"])
            if lo_km + 0.5 < bkm < hi_km - 0.5:
                mid_pts.append((bkm, float(bwp["lat"]), float(bwp["lng"])))

    mid_pts.sort(key=lambda x: x[0], reverse=not forward)
    coords = [(u_lat, u_lng)]
    for _, mlat, mlng in mid_pts:
        if (mlat, mlng) != coords[-1]:
            coords.append((mlat, mlng))
    if (v_lat, v_lng) != coords[-1]:
        coords.append((v_lat, v_lng))
    return coords


def build_database(target_path: Path | None = None, only_if_missing: bool = False) -> Path:
    db_path = Path(target_path) if target_path else DEFAULT_DB_PATH
    if only_if_missing and db_path.exists() and db_path.stat().st_size > 0:
        return db_path

    db_path.parent.mkdir(parents=True, exist_ok=True)
    schema_sql = SCHEMA_PATH.read_text(encoding="utf-8")
    seed_data = json.loads(SEED_JSON_PATH.read_text(encoding="utf-8"))
    raw_candidates = json.loads(RAW_CANDIDATES_PATH.read_text(encoding="utf-8"))

    fd, tmp_name = tempfile.mkstemp(prefix="happy_path_seed_", suffix=".db", dir="/tmp")
    os.close(fd)
    tmp_db = Path(tmp_name)

    conn = sqlite3.connect(str(tmp_db))
    try:
        conn.executescript(schema_sql)
        for corr in seed_data["corridors"]:
            cid = corr["corridor_id"]
            spine_wps = corr.get("spine_waypoints", [])
            toll_plazas = corr.get("toll_plazas", [])
            conn.execute(
                """INSERT INTO corridors (
                    corridor_id, name_vi, origin_name, dest_name,
                    origin_aliases_json, dest_aliases_json,
                    origin_lat, origin_lng, dest_lat, dest_lng,
                    total_spine_km, base_vetc_toll_vnd, spine_waypoints_json, toll_plazas_json
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    cid, corr["name_vi"], corr["origin_name"], corr["dest_name"],
                    json.dumps(corr["origin_aliases"], ensure_ascii=False),
                    json.dumps(corr["dest_aliases"], ensure_ascii=False),
                    corr["origin_lat"], corr["origin_lng"],
                    corr["dest_lat"], corr["dest_lng"],
                    corr["total_spine_km"], corr.get("base_vetc_toll_vnd", 0),
                    json.dumps(spine_wps, ensure_ascii=False),
                    json.dumps(toll_plazas, ensure_ascii=False),
                ),
            )

            branches_map = {}
            for br in corr.get("branches", []):
                branches_map[br["branch_id"]] = br
                conn.execute(
                    """INSERT INTO corridor_branches (
                        branch_id, corridor_id, name_vi, diverge_km, merge_km,
                        toll_delta_vnd, real_branch_km, branch_waypoints_json
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                    (
                        br["branch_id"], cid, br["name_vi"], br["diverge_km"], br["merge_km"],
                        br["toll_delta_vnd"], br.get("real_branch_km", round(br["merge_km"] - br["diverge_km"], 1)),
                        json.dumps(br.get("branch_waypoints", []), ensure_ascii=False),
                    ),
                )

            for tp in toll_plazas:
                conn.execute(
                    """INSERT INTO toll_plazas (
                        plaza_id, corridor_id, branch_id, name_vi, corridor_km,
                        lat, lng, fee_vnd, operator, source_url
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (
                        tp["plaza_id"], cid, tp.get("branch_id", "MAIN_SPINE"),
                        tp["name_vi"], tp["corridor_km"], tp["lat"], tp["lng"],
                        tp["fee_vnd"], tp.get("operator", "VETC"), tp["source_url"],
                    ),
                )

            pois = corr["pois"]
            for p in pois:
                is_24h = 1 if (p["open_minute"] == 0 and p["close_minute"] == 1440) else p.get("is_24h", 0)
                conn.execute(
                    """INSERT INTO pois (
                        poi_id, corridor_id, branch_id, goong_place_id, name_vi, commune_name, category,
                        lat, lng, corridor_km, direction_allowed, sedan_safe,
                        has_ev_charge, ev_max_kw, ev_stall_count, ev_connector_type, is_24h,
                        midday_sun_trap, is_arrival_anchor, exertion_level,
                        dwell_minutes, open_minute, close_minute,
                        utility_score, scenic_score, google_rating, user_rating_count,
                        detour_minutes, hazard_level, archetype_affinity, tradeoff_note_vi, source_url
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (
                        p["poi_id"], cid, p.get("branch_id", "MAIN_SPINE"), p["goong_place_id"],
                        p["name_vi"], p["commune_name"], p["category"],
                        p["lat"], p["lng"], p["corridor_km"], p["direction_allowed"], p["sedan_safe"],
                        p.get("has_ev_charge", 0), p.get("ev_max_kw", 0), p.get("ev_stall_count", 0),
                        p.get("ev_connector_type", "NONE"), is_24h,
                        p.get("midday_sun_trap", 0), p.get("is_arrival_anchor", 0),
                        p.get("exertion_level", "LOW"),
                        p["dwell_minutes"], p["open_minute"], p["close_minute"],
                        p["utility_score"], p["scenic_score"],
                        p.get("google_rating", 4.2), p.get("user_rating_count", 100),
                        p["detour_minutes"], p["hazard_level"], p["archetype_affinity"],
                        p["tradeoff_note_vi"], p["source_url"],
                    ),
                )

            for co in corr.get("co_occurrence", []):
                conn.execute(
                    """INSERT INTO poi_co_occurrence (corridor_id, from_poi_id, to_poi_id, synergy_bonus, source_urls_json)
                       VALUES (?, ?, ?, ?, ?)""",
                    (
                        cid,
                        co["from_poi_id"],
                        co["to_poi_id"],
                        co["synergy_bonus"],
                        json.dumps(co.get("source_urls", []), ensure_ascii=False),
                    ),
                )

            nodes = [("ORIGIN", 0.0, 0, 0.0, "MAIN_SPINE", corr["origin_lat"], corr["origin_lng"])]
            for p in pois:
                nodes.append((p["poi_id"], p["corridor_km"], p["detour_minutes"], p["hazard_level"], p["branch_id"], p["lat"], p["lng"]))
            nodes.append(("DEST", corr["total_spine_km"], 0, 0.0, "MAIN_SPINE", corr["dest_lat"], corr["dest_lng"]))

            for u_id, u_km, u_det, u_haz, u_br, u_lat, u_lng in nodes:
                for v_id, v_km, v_det, v_haz, v_br, v_lat, v_lng in nodes:
                    if u_id == v_id:
                        continue
                    if not _is_pair_physically_connected(u_br, u_km, v_br, v_km, branches_map):
                        continue
                    dist = abs(v_km - u_km)
                    if dist < 0.5:
                        dist = 2.0
                    edge_coords = _build_branch_aware_edge_coords(
                        u_lat, u_lng, u_km, u_br,
                        v_lat, v_lng, v_km, v_br,
                        spine_wps, branches_map
                    )
                    poly = _encode_coords_polyline(edge_coords)
                    for bucket, (speed_kmh, detour_mult) in TIME_BUCKETS.items():
                        base_drive = (dist / speed_kmh) * 60.0
                        detour_cost = (v_det * 0.65) * detour_mult
                        drive_min = max(5, int(round(base_drive + detour_cost)))
                        haz = round(max(u_haz, v_haz) * (1.5 if bucket == "rain_evening" else 1.0), 3)
                        conn.execute(
                            """INSERT INTO corridor_edges (
                                corridor_id, from_node, to_node, time_bucket,
                                drive_minutes, distance_km, hazard_penalty, encoded_polyline
                            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                            (cid, u_id, v_id, bucket, drive_min, round(dist, 2), haz, poly),
                        )

        for rc in raw_candidates:
            rec_revs = rc.get("recent_90d_reviews", [])
            low_revs = rc.get("low_review_samples") or rc.get("sampled_low_reviews", [])
            conn.execute(
                """INSERT INTO ingestion_audit_log (
                    candidate_id, corridor_id, place_id, venue_name, expected_commune, goong_returned_commune,
                    lifetime_rating, trailing_90d_rating, user_rating_count, recent_90d_review_count, low_review_sample_count,
                    accepted, rejection_reason, scrubbed_testimonial, source_url
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    rc["candidate_id"], rc["corridor_id"], rc.get("place_id", "ChIJ_UNKNOWN"), rc["venue_name"],
                    rc["expected_commune"], rc["goong_returned_commune"],
                    rc["lifetime_rating"], rc["trailing_90d_rating"], rc.get("user_rating_count", 100),
                    len(rec_revs), len(low_revs),
                    1 if rc["accepted"] else 0, rc["rejection_reason"],
                    rc["scrubbed_testimonial"], rc["source_url"],
                ),
            )
            for rv in rec_revs:
                conn.execute(
                    """INSERT INTO poi_reviews (
                        candidate_id, poi_id, corridor_id, review_type, source_channel,
                        review_date, star_rating, scrubbed_body_vi, source_url
                    ) VALUES (?, ?, ?, 'RECENT_90D', ?, ?, ?, ?, ?)""",
                    (
                        rc["candidate_id"], rc.get("poi_id"), rc["corridor_id"],
                        rv.get("source_channel", "google_maps"),
                        rv["review_date"], rv["star_rating"], rv["scrubbed_body_vi"], rv["source_url"],
                    ),
                )
            for rv in low_revs:
                conn.execute(
                    """INSERT INTO poi_reviews (
                        candidate_id, poi_id, corridor_id, review_type, source_channel,
                        review_date, star_rating, scrubbed_body_vi, source_url
                    ) VALUES (?, ?, ?, 'LOW_SAMPLE', ?, ?, ?, ?, ?)""",
                    (
                        rc["candidate_id"], rc.get("poi_id"), rc["corridor_id"],
                        rv.get("source_channel", "google_maps"),
                        rv["review_date"], rv["star_rating"], rv["scrubbed_body_vi"], rv["source_url"],
                    ),
                )
        conn.commit()
    finally:
        conn.close()

    dest_tmp = db_path.parent / f".{db_path.name}.tmp.{os.getpid()}"
    shutil.copy2(str(tmp_db), str(dest_tmp))
    os.replace(str(dest_tmp), str(db_path))
    tmp_db.unlink(missing_ok=True)
    print(f"[OK] Atomically built and published v5.0 SQLite database at {db_path}")
    return db_path


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Compile Happy Path SQLite database from seed JSON.")
    parser.add_argument("--db-path", type=str, default=None, help="Target SQLite path (defaults to HAPPY_PATH_DB_PATH)")
    parser.add_argument("--if-missing", action="store_true", help="Only build if target DB does not already exist")
    args = parser.parse_args()
    build_database(Path(args.db_path) if args.db_path else None, only_if_missing=args.if_missing)
